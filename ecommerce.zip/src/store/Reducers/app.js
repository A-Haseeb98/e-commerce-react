const INITIAL_STATE = {
    user: "ghous"
}

const app = (state = INITIAL_STATE) => {
    return state
}

export default app;