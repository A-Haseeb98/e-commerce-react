import './style/style.css'
import { Product } from '../../components';
function Shop() {
    return (
        <div>
            <h1>Shop</h1>
            <div className='container-fluid test'>
                <div className='row'>
                    <div className='col-2 left'>
                        left
                    </div>
                    <div className='col-10 right'>

                    <div className="row d-flex flex-wrap justify-content-around">
                        <Product/>
                        <Product/>
                        <Product/>
                        <Product/>
                        <Product/>
                        <Product/>
                        <Product/>
                        <Product/>
                        <Product/>
                        <Product/>

                    </div>
                       
                    </div>
                </div>


            </div>
        </div>
    )
}

export default Shop;