import NavBar from "./NavBar";
import Slider from "./Slider";
import Product from "./Product";
export {
    NavBar,
    Slider,
    Product
}